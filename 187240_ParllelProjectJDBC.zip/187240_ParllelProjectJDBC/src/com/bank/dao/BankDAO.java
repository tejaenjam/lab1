package com.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Random;

import com.bank.beans.BankBean;
import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;


public class BankDAO
{
	String transtype,transdesc;
	long transid,transid1;
	Random rand = new Random();
	Connection conn=null;
	PreparedStatement ps = null;
	BankBean bankBean = new BankBean();
	
	public boolean createAccount(BankBean bankBean) throws AccountNotCreatedException, SQLException, ClassNotFoundException
	{
		conn = BankDB.getConnection();
		String ins_str ="insert into bank values(?,?,?,?,?)";
		
		ps = conn.prepareStatement(ins_str);
		
		ps.setString(1,bankBean.getName());
		ps.setLong(2,bankBean.getAccountNo());
		ps.setString(3,bankBean.getPassword());
		ps.setString(4, bankBean.getPhoneNo());
		ps.setInt(5,bankBean.getBalance());
		 int ans = ps.executeUpdate();
		 if(ans>0)
		    return true;
		 else 
			 return false;
	
	}


	public int showBalance(long accountNo) throws ZeroBalanceException, ClassNotFoundException, SQLException
	{
		int balance=0;
		conn = BankDB.getConnection();
		String ins_str ="select balance from bank where accountNo=?";
		ps = conn.prepareStatement(ins_str);
		
		ps.setLong(1, accountNo);

			 ResultSet rs = ps.executeQuery();
			 while(rs.next())
			 {
				 balance =rs.getInt(1);
			 }
			 return balance;
	}
	
	public int depositAmount(long accountNo, int balance1) throws SQLException, ClassNotFoundException
	{
		int balance=0;
		conn = BankDB.getConnection();
		String ins_str ="update bank set balance=? where accountNo=?";
         ps = conn.prepareStatement(ins_str);
		  ps.setInt(1, balance1);
		  ps.setLong(2, accountNo);
		  int ans =ps.executeUpdate();
		  
			
		  if(ans>0)
		  {
				String ins_str1 ="select balance from bank where accountNo=?";
				ps = conn.prepareStatement(ins_str1);
			     ps.setLong(1, accountNo);

			  ResultSet rs = ps.executeQuery();
			  while(rs.next())
				  balance =rs.getInt(1);
		  }
		     transid = rand.nextInt(100000); 
			transtype="Deposite";
			transdesc="Transaction ID : "+transid+" Account Credited by : "+balance+" \n";
			
			String saveTrans = "insert into transaction values (?,?,?,?)";
			ps = conn.prepareStatement(saveTrans);
			ps.setLong(1, transid);
			ps.setString(2, transtype);
			ps.setLong(3, accountNo);
			ps.setString(4, transdesc);
			ps.executeUpdate(); 
			
		  return balance;
		  
		
	}
	
	public int  withdrawAmount(long accountNo, int balance1) throws InsufficientBalanceException, ClassNotFoundException, SQLException
	{
		int balance=0;
		conn = BankDB.getConnection();
		String ins_str ="update bank set balance=? where accountNo=?";
         ps = conn.prepareStatement(ins_str);
		  ps.setInt(1, balance1);
		  ps.setLong(2, accountNo);
		  int ans =ps.executeUpdate();
		  if(ans>0)
		  {
				String ins_str1 ="select balance from bank where accountNo=?";
				ps = conn.prepareStatement(ins_str1);
			     ps.setLong(1, accountNo);

			  ResultSet rs = ps.executeQuery();
			  while(rs.next())
				  balance =rs.getInt(1);
		  }
		  
		  transid = rand.nextInt(100000); 
			transtype="Withdraw";
			transdesc="Transaction ID : "+transid+" Updated Balance : "+balance+" \n";
			
			String Q_Trans = "insert into transaction values (?,?,?,?)";
			
			ps = conn.prepareStatement(Q_Trans);
			
			ps = conn.prepareStatement(Q_Trans);
			ps.setLong(1, transid);
			ps.setString(2, transtype);
			ps.setLong(3, accountNo);
			ps.setString(4, transdesc);
			ps.executeUpdate(); 
		  return balance;
		
	}
	public boolean fundTransfer(long accountNo, long accno, int amount) throws ClassNotFoundException, SQLException
	{   
		int bal=0,balance=0;
		conn = BankDB.getConnection();
		String ins_str = "select balance from bank where accountNo=?";
		ps = conn.prepareStatement(ins_str);
	    ps.setLong(1, accno);
		
	    ResultSet rs = ps.executeQuery();
		  while(rs.next())
		bal =rs.getInt(1);
	    balance = bal+amount;
	    
	    transid = rand.nextInt(100000);
		transid1 = rand.nextInt(100000);
		

		String trans1="Amount Transferred to : "+accno+" Updated Balance :"+2000+" \n";
		String trans2="Amount Received from : "+accountNo+" Updated Balance :"+balance+" \n";

		String Q_Trans = "insert into transaction values (?,?,?,?)";
		ps= conn.prepareStatement(Q_Trans);
		transtype="Fund Transfer";

		ps = conn.prepareStatement(Q_Trans);
		ps.setLong(1, transid);
		ps.setString(2, transtype);
		ps.setLong(3, accountNo);
		ps.setString(4, trans1);
		ps.executeUpdate(); 
		
		ps = conn.prepareStatement(Q_Trans);

		ps = conn.prepareStatement(Q_Trans);
		ps.setLong(1, transid1);
		ps.setString(2, transtype);
		ps.setLong(3, accno);
		ps.setString(4, trans2);
		ps.executeUpdate(); 
			String ins_str1 = "update bank set balance=? where accountNo=?";
			ps = conn.prepareStatement(ins_str1);
			ps.setInt(1, balance);
			ps.setLong(2, accno);
			int ans = ps.executeUpdate();
			if(ans!=0)
				return true;
			else
				return false;
		
	}
	public boolean validateAccount(long accountNo,String password) throws ClassNotFoundException, SQLException
	{
		Long accountNo1=0L;
		String password1="";
		conn = BankDB.getConnection();
		String ins_str ="select accountNo ,password from bank where accountNo=?";
		ps = conn.prepareStatement(ins_str);
	      ps.setLong(1, accountNo);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			accountNo1 = rs.getLong(1);
			password1 = rs.getString(2);
		}
		if(accountNo==accountNo1&&password.equals(password1))
			return true;
		else
			return false;
	}


	public String getTransaction(long accountNo) throws SQLException {
		
		String getTrans = "select * from transaction where accountNo= ?";
		ps = conn.prepareStatement(getTrans);
		ps.setLong(1,accountNo);
		ResultSet rs = ps.executeQuery(); 
		String str="";
		while(rs.next()) 
		{str=str+Long.toString(rs.getLong(1))+"  "+	
		rs.getString(2) + "  "+	Long.toString(rs.getLong(3)) +"  "+	
		rs.getString(4);}
		return str;
	}
	
}
