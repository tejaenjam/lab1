package com.bank.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BankDB 
{
	 public static Connection getConnection() throws ClassNotFoundException, SQLException
	  {
		  String driverName = "oracle.jdbc.OracleDriver";
		  Class.forName(driverName);
		  Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","teja","enjam123");
		  return conn;
	  }
}
