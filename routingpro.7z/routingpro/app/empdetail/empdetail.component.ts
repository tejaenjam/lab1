
import { Component, OnInit } from '@angular/core';
import {Employee,MyserviceService } from '../myservice.service';
@Component({
  selector: 'empdetail',
  templateUrl: './empdetail.component.html',
  styleUrls: ['./empdetail.component.css']
})
export class  EmpdetailComponent implements OnInit {
  ngOnInit() {
  }
  a:Employee;
  s:MyserviceService;
  b:boolean=false;
 

  constructor(s:MyserviceService) {this.s=s;
   }

  
  add(o:any){
    this.a=new
    Employee(o.id,o.name,o.gender,o.sal);
    this.s.add(this.a);
    this.b=true;
    // console.log(data.ename);
    // console.log(data.eid);
  

  }

}