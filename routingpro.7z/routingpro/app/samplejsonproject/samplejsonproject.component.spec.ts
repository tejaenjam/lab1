import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SamplejsonprojectComponent } from './samplejsonproject.component';

describe('SamplejsonprojectComponent', () => {
  let component: SamplejsonprojectComponent;
  let fixture: ComponentFixture<SamplejsonprojectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SamplejsonprojectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SamplejsonprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
