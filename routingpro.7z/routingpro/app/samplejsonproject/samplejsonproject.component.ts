import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-samplejsonproject',
  templateUrl: './samplejsonproject.component.html',
  styleUrls: ['./samplejsonproject.component.css']
})
export class SamplejsonprojectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
