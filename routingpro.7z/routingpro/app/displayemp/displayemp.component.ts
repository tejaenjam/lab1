
import { Component, OnInit } from '@angular/core';
import {Employee,MyserviceService } from '../myservice.service';

@Component({
  selector: 'displayemp',
  templateUrl: './displayemp.component.html',
  styleUrls: ['./displayemp.component.css']
})
export class DisplayempComponent implements OnInit {
  service:MyserviceService;
  constructor(service:MyserviceService) {
    this.service=service;
   }
employees:Employee[]=[]
id1()
{
  this.employees=this.service.id2();
}
name1()
{
  this.employees=this.service.name2();
}
delete(id:number)
{
  this.service.delete(id);
  this.employees=this.service.getEmployees();
}
  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
