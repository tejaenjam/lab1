import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../Models/Customer';
import { Transactions } from '../Models/Transactions';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  isLogin:boolean=true;
  customers:Customer[]=[];
  transactions:Transactions[]=[];
  tempTransaction:Transactions[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchCustomers();
    this.fetchTransactions();
  }

  fetchCustomers()
  {
    this.http.get('./assets/Customer.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Customer(o.caccount,o.cname,o.cphone,o.cpassword,o.ccity,o.cbalance);
      this.customers.push(e);
    }
  }

  fetchTransactions()
  {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }

  convertTransaction(dataT:any)
  {
    for(let o of dataT)
    {
      let e=new Transactions(o.tid,o.taccount_sender,o.taccount_reciver,o.tamount,o.ttype);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }

  getCustomers():Customer[]
  {
    return this.customers;
  }

  getTransactions():Transactions[]
  {
    return this.transactions;
  }

  miniStatement(caccount:string):Transactions[]{
    this.tempTransaction=[];
    for(let i=0;i<this.transactions.length;i++)
    {
      let e=this.transactions[i];
      if(caccount==e.taccount_sender)
      {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }

  add(e:Customer){
    this.customers.push(e);
    var myJSON = JSON.stringify(this.customers);
  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:Customer):number{
    let caccount = data.caccount; 
    for(let i=0;i<this.customers.length;i++)
      {
        if(caccount == this.customers[i].caccount)
        {
          let cbalance=this.customers[i].cbalance;
          return cbalance;
        }else{
          continue;
        }
      }
      alert("Account No does not matched!")
  }

  depositeBalance(caccount_first:number,cbalance:number){
      console.log(caccount_first,cbalance)

      for(let i=0;i<this.customers.length;i++)
      {
        if(caccount_first == this.customers[i].caccount)
        {
          let depositeB:number=this.customers[i].cbalance;
          this.customers[i].cbalance=parseInt(depositeB.toString()) + parseInt(cbalance.toString());
          alert("Amount Deposited from "+caccount_first+"\nUpdated Balance : "+this.customers[i].cbalance);
          break;
        }
      }
  }
  
  withdrawBalance(caccount_first:number,cbalance:number){
    for(let i=0;i<this.customers.length;i++)
    {
      console.log(this.customers[i])
      if(caccount_first == this.customers[i].caccount)
      {
        let withdrawB:number=this.customers[i].cbalance;
        this.customers[i].cbalance=parseInt(withdrawB.toString()) - parseInt(cbalance.toString());
        alert("Amount Withdrawn from "+caccount_first+"\nUpdated Balance : "+this.customers[i].cbalance);
        break;
      }
    }
  }

  login(data:Customer):boolean
  {
    let caccount=data.caccount;
    let cpassword=data.cpassword;

    for(let a of this.customers)
    {
      console.log(this.customers)
      if(caccount == a.caccount && cpassword == a.cpassword)
      {
       
        alert("Value Matched!")
        this.isLogin=!this.isLogin;
        return true;
      }else {
        continue;
      }
      
    }
    return false;
  }
 
}

