import { TestBed } from '@angular/core/testing';

import { ServicelayerService } from './servicelayer.service';

describe('ServicelayerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServicelayerService = TestBed.get(ServicelayerService);
    expect(service).toBeTruthy();
  });
});
