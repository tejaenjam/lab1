import { TestBed } from '@angular/core/testing';

import { SlayerService } from './slayer.service';

describe('SlayerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SlayerService = TestBed.get(SlayerService);
    expect(service).toBeTruthy();
  });
});
