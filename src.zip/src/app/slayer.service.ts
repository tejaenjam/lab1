import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SlayerService {

empbean:employeebean[]=[];
hc:HttpClient;

constructor(hc:HttpClient) {this.hc=hc; }

  
ab:boolean=false;
fetchinfo(){
  this.hc.get("./assets/employeedetails.json").subscribe
  (data1=>{
    if(!this.ab)
    {
      this.convert(data1);
      this.ab=true;
    }
  });
}
convert(d :any)
{
  for(let o of d)
  {
    let e=new employeebean(o.name,o.gender,o.id,o.salary,o.dob,o.contact)
    this.empbean.push(e);
  }
}


getinfo():employeebean[]{
  return this.empbean;
}


delete(id1:number)
{
  let  x:number=-1;
 for(let i=0;i< this.empbean.length;i++)
 {
   let e=this.empbean[i];
   if(id1==e.id)
   {
     x=i;
     break;
   }
 }
 this.empbean.splice(x,1);
 console.log(this.empbean)
}

add(o:any)
{
  this.empbean.push(o);
}

update(data:any)
  {
    
    let eid=data.eid;
    
    for(let i=0;i<this.empbean.length;i++)
    {
      
      if(eid == this.empbean[i].id)
      {
        this.empbean[i].salary=data.Salary;
        let a =this.empbean[0].contact[1];
       
        for(let l in this.empbean[i]){
          if(l === "contact"){
            this.empbean[i].contact[0] = data.econtact;
            
            this.empbean[i].contact[1] = "1246";
          }
          
        }
        // console.log("from service sal "+this.empbean[i].salary +"  "+this.empbean[i].contact)
        break;
      }
    }
  }

  search(id:number):employeebean
  {
   
    let o:employeebean
    for(let i=0;i<this.empbean.length;i++)
    {
     
       o =  this.empbean[i];
      if(id==o.id)
      {
        return o; 
      }
    } 
  }
}


export class employeebean{
  name:string;
  gender:string;
  id:number;
  salary:number;
  dob:string;
  contact:string[];
  constructor(name:string,gender:string,id:number,salary:number,dob:string,contact:string[])
  {
    this.name=name;
    this.gender=gender;
    this.id=id;
    this.salary=salary;
    this.dob=dob;
    this.contact=contact;
  }
}
