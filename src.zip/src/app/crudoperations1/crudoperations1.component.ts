import { Component, OnInit } from '@angular/core';
import { SlayerService, employeebean } from '../slayer.service';

@Component({
  selector: 'app-crudoperations1',
  templateUrl: './crudoperations1.component.html',
  styleUrls: ['./crudoperations1.component.css']
})
export class Crudoperations1Component implements OnInit {
service:SlayerService;
emp:employeebean;
  constructor(service:SlayerService) {this.service=service }

b:boolean=false;
  add(o:any)
  {
    this.emp=new employeebean(o.name,o.gender,o.id,o.salary,o.dob,[o.contact,o.contact1]);
    this.service.add(this.emp);
    this.b=true;
  }
  ngOnInit() {
   
  }

}
