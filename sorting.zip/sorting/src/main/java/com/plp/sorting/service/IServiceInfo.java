package com.plp.sorting.service;

import java.util.List;

import com.plp.sorting.bean.Category;
import com.plp.sorting.bean.Product;

public interface IServiceInfo {
	public long productData(Product product);

	public long catagoryData(Category category);

	public List<Product> sortByPriceAscending(String item);

	public List<Product> sortByPriceDescending(String item);

	public List<Product> searchByGender(String categoryName);

	public List<Product> searchByType(String item);

	public List<Product> priceRange(String productname, double minprice, double maxprice);

	public List<Product> sortByViews(String productname);

	public List<Product> sortByRating(String productname);
}
