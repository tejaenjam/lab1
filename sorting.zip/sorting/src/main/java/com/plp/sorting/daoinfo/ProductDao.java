package com.plp.sorting.daoinfo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.plp.sorting.bean.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Long> {
	@Query(value = "SELECT * FROM capstore_products WHERE PRODUCT_NAME=:item ORDER BY PRODUCT_PRICE ASC", nativeQuery = true)
	List<Product> sortByPriceAscending(@Param("item") String item);

	@Query(value = "SELECT * FROM capstore_products WHERE PRODUCT_NAME=:item ORDER BY PRODUCT_PRICE DESC", nativeQuery = true)
	List<Product> sortByPriceDescending(@Param("item") String item);

	@Query("select t.categoryId from Category t where categoryGender=?1 ")
	Long searchByGender(String categoryName);

	@Query(value = "SELECT * FROM capstore_products  where category_id=?1", nativeQuery = true)
	List<Product> findCategoryById(Long categoryid);

	@Query("select t.categoryId from Category t where categoryType=?1 ")
	Long searchByType(String item);

	@Query(value = "select * from capstore_products  where PRODUCT_NAME=:name and PRODUCT_PRICE between :min and :max", nativeQuery = true)
	List<Product> priceRange(@Param("name") String productname, @Param("min") double minprice,@Param("max") double maxprice);

	
	@Query(value="select * from capstore_products WHERE PRODUCT_NAME=:u ORDER BY PRODUCT_VIEWS DESC",nativeQuery=true)
	List<Product> sortByViews(@Param("u") String productname);
	
	@Query(value="select * from capstore_products WHERE PRODUCT_NAME=:u ORDER BY PRODUCT_RATING DESC",nativeQuery=true)
	List<Product> sortByRating(@Param("u") String productname);

}
