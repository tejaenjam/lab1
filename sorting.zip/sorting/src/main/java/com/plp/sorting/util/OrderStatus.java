package com.plp.sorting.util;

public enum OrderStatus 
{ 
    BeingPrepared, Ready, Shipped, Delivered; 
} 