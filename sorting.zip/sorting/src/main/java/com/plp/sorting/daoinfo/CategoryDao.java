package com.plp.sorting.daoinfo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.plp.sorting.bean.Category;

@Repository
public interface CategoryDao extends JpaRepository<Category, Long> {

}
