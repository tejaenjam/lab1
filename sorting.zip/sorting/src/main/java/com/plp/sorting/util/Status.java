package com.plp.sorting.util;

public enum Status {
	Active, Blocked
}