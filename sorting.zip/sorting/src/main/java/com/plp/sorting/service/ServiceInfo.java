package com.plp.sorting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plp.sorting.bean.Category;
import com.plp.sorting.bean.Product;
import com.plp.sorting.controller.UserException;
import com.plp.sorting.daoinfo.CategoryDao;
import com.plp.sorting.daoinfo.ProductDao;

@Service
public class ServiceInfo implements IServiceInfo {
	@Autowired
	ProductDao productdao;
	@Autowired
	CategoryDao sortingdao;

	public long productData(Product product) {
		productdao.save(product);
		long productid = product.getProductId();
		return productid;
	}

	public long catagoryData(Category category) {
		sortingdao.save(category);
		long categoryid = category.getCategoryId();
		return categoryid;
	}

	public List<Product> sortByPriceAscending(String item) {
		List<Product> sortingDataAsc = productdao.sortByPriceAscending(item);
		if (sortingDataAsc.isEmpty()) {
			throw new UserException("enter correct item");
		} else {
			return sortingDataAsc;
		}
	}

	public List<Product> sortByPriceDescending(String item) {
		List<Product> sortingDataDsc = productdao.sortByPriceDescending(item);
		if (sortingDataDsc.isEmpty()) {
			throw new UserException("enter correct item");
		} else {
			return sortingDataDsc;
		}
	}

	public List<Product> searchByGender(String categoryName) {
		Long categoryid = productdao.searchByGender(categoryName);
		if (categoryid == null) {
			throw new UserException("Invalid Selection for gender");
		} else {
			List<Product> searchbyid = productdao.findCategoryById(categoryid);
			if (searchbyid.isEmpty()) {
				throw new UserException("enter correct item");
			} else {
				return searchbyid;
			}
		}
	}

	public List<Product> searchByType(String item) {
		Long categoryid = productdao.searchByType(item);
		if (categoryid == null) {
			throw new UserException("Invalid Selection ");
		} else {
			List<Product> searchbyid = productdao.findCategoryById(categoryid);
			if (searchbyid.isEmpty()) {
				throw new UserException("enter correct item");
			} else {
				return searchbyid;
			}
		}
	}

	public List<Product> priceRange(String productname, double minprice, double maxprice) {
		List<Product> pricerange = productdao.priceRange(productname, minprice, maxprice);
		if (pricerange.isEmpty()) {
			throw new UserException("enter correct item");
		} else {
			return pricerange;
		}
	}

	public List<Product> sortByViews(String productname) {
		List<Product> sortbyviews = productdao.sortByViews(productname);
		if (sortbyviews.isEmpty()) {
			throw new UserException("enter correct data");
		} else {
			return sortbyviews;
		}
	}

	public List<Product> sortByRating(String productname) {
		List<Product> sortbyviews = productdao.sortByRating(productname);
		if (sortbyviews.isEmpty()) {
			throw new UserException("enter correct data");
		} else {
			return sortbyviews;
		}
	}

}
