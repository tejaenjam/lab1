import { Component, OnInit } from '@angular/core';
import { SlayerService, employeebean } from '../slayer.service';

@Component({
  selector: 'app-searchop',
  templateUrl: './searchop.component.html',
  styleUrls: ['./searchop.component.css']
})
export class SearchopComponent implements OnInit {

service:SlayerService;
emp:employeebean;
  constructor(service:SlayerService) {this.service=service }

  
search(data:any)
{
  let id1:number =data.id;
this.emp=this.service.search(id1);
console.log(this.emp)


}
  ngOnInit() {
    this.service.fetchinfo();
  }

}
