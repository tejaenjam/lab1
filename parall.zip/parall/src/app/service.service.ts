import { Injectable } from '@angular/core';
import { Customer } from 'src/Models/Customer';
import { Transactions } from 'src/Models/Transactions';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  
  isLogin:boolean=true;
  customers:Customer[]=[];
  transactions:Transactions[]=[];
  tempTransaction:Transactions[]=[];
  fetched:boolean=false;
  fetchedT:boolean=false;
  createdAccount: Customer;
  getCustomers():Customer[]
  {
    return this.customers;
  }
  
  login(data:any):boolean
  {
    let caccount=data.caccount;
    let cpassword=data.cpassword;
    
    for(let a of this.customers)
    {
      console.log(a.caccount+" "+a.cpassword)
      console.log(this.customers)
      if(caccount == a.caccount && cpassword == a.cpassword)
      {
       
        alert("Value Matched!")
        this.isLogin=!this.isLogin;
        return true;
      }else {
        continue;
      }
      
    }
    return false;
  }
  showBalance(data:any):number{
    let caccount = data.caccount; 
    console.log(caccount);
    for(let i=0;i<this.customers.length;i++)
      {
        if(caccount == this.customers[i].caccount)
        {
          let cbalance=this.customers[i].cbalance;
          return cbalance;
        }else{
          continue;
        }
      }
      alert("Account No does not matched!")
  }
  
  constructor() { 
    // this.fetchCustomers();
    // this.fetchTransactions();
  }
  
  add(name:string,phone:number,password:string,city:string){
    Customer.caccount=phone;
    Customer.cbalance=5000;
   var b =new Customer(Customer.caccount,name,phone,password,city,Customer.cbalance);
   this.customers.push(b);
   return Customer.caccount;
  }

  // add(e:Customer){
  //   this.customers.push(e);
  //   var myJSON = JSON.stringify(this.customers);
  // }
  addTransactions(createdTransaction: Transactions): any {
    throw new Error("Method not implemented.");
  }
  addTransaction(e:Transactions){
    this.transactions.push(e);
  }


  
}
