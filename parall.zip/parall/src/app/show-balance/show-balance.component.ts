import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/Models/Customer';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  isLogin:boolean=true;
  customers:Customer[]=[];
  cbalance:number;
  router:Router;
  isShowBalance:boolean=true;
  service:ServiceService;

  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }

  showBalance(data:any){
     this.cbalance=this.service.showBalance(data);
     alert("Current balance : "+this.cbalance)
     this.isShowBalance=!this.isShowBalance;
     this.router.navigate(['view']);
  }

  ngOnInit() {
    this.customers=this.service.getCustomers();
  }

}
