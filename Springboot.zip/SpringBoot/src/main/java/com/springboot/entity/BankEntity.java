package com.springboot.entity;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="bank_project")
public class BankEntity {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long caccount;
	
	private String cname;

	private String cphone;

	private String cpassword;

	private Integer cbalance;

	private String ccity;
	
	public BankEntity(Long caccount, String cname, String cphone, String cpassword, Integer cbalance, String ccity) {
		super();
		this.caccount = caccount;
		this.cname = cname;
		this.cphone = cphone;
		this.cpassword = cpassword;
		this.cbalance = cbalance;
		this.ccity = ccity;
	}
	public Long getCaccount() {
		return caccount;
	}
	public void setCaccount(Long caccount) {
		this.caccount = caccount;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCphone() {
		return cphone;
	}
	public void setCphone(String cphone) {
		this.cphone = cphone;
	}
	public String getCpassword() {
		return cpassword;
	}
	public void setCpassword(String cpassword) {
		this.cpassword = cpassword;
	}
	public Integer getCbalance() {
		return cbalance;
	}
	public void setCbalance(Integer cbalance) {
		this.cbalance = cbalance;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
	public BankEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

//	@GeneratedValue(strategy=GenerationType.AUTO,generator="qwer")
//	@SequenceGenerator(name="qwer",sequenceName="Sqn")
//	CREATE SEQUENCE sequence_name
//	START WITH initial_value
//	INCREMENT BY increment_value
//	MINVALUE minimum value
//	MAXVALUE maximum value
//	CYCLE|NOCYCLE ;
	
	
	

}
