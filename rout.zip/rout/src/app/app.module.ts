import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpdetailComponent } from './empdetail/empdetail.component';
import { DisplayempComponent } from './displayemp/displayemp.component';
import { MyserviceService } from './myservice.service';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { SamplejsonprojectComponent } from './samplejsonproject/samplejsonproject.component';
@NgModule({
  declarations: [
    AppComponent,
    EmpdetailComponent,
    DisplayempComponent,
    SamplejsonprojectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [MyserviceService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
