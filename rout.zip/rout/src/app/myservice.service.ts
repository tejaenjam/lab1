import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
http:HttpClient;
employees:Employee[]=[];
  constructor(http:HttpClient) {
    this.http=http; 
  }
  fetched:boolean=false;
  fetchEmployees()
  {
    this.http.get('./assets/employee.json')
    
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;

        }
      }
    );
  }
  getEmployees() :Employee[]{
    return this.employees;
  }
  add(a:Employee)
  {
    this.employees.push(a)
  }
  convert(data:any)
  {
    for(let o of data){
      let e=new Employee(o.id,o.name,o.gender,o.sal);
      this.employees.push(e);
    }
  }
  a2:boolean=false;
  name2():Employee[]
  {
    if(!this.a2)
    {
    let br=this.employees.sort((a,b)=>{
      if(a.name<b.name) return -1;
      else if(a.name>b.name) return 1;
      else return 0;
    });
    this.a2=true;
    return br;
  }
  else{
    let br=this.employees.sort((a,b)=>{
      if(a.name<b.name) return 1;
      else if(a.name>b.name) return -1;
      else return 0;
    });
    this.a2=false;
    return br;
  }
}
  a3:boolean=false;
  id2():Employee[]
  {
    if(!this.a3)
    {
let br=this.employees.sort((a,b)=>{return b.id - a.id});
this.a3=true;
return br;
  }
  else{
    let br=this.employees.sort((a,b)=>{return a.id - b.id});
    this.a3=false;
return br;
  }
  }
  delete(id:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let e=this.employees[i];
      if(id==e.id)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }
}
export class Employee{
  id:number;
  name:string;
  gender:string;
  sal:number;
  constructor(id:number,name:string,gender:string,sal:number)
  {
    this.gender=gender;
    this.name=name;
    this.sal=sal;
    this.id=id;
  }
}
