package com.cap.exception;

public class DataNotFoundException extends RuntimeException{
	public DataNotFoundException(String e)
	{
		super(e);
	}
	public DataNotFoundException()
	{
		super();
	}

}
