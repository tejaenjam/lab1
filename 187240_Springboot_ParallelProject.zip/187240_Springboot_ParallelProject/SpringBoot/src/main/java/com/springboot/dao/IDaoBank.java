package com.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.entity.BankEntity;

@Repository
public interface IDaoBank extends JpaRepository<BankEntity, Long>{

}
