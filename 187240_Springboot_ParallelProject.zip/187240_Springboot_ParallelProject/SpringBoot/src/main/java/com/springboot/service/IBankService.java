package com.springboot.service;

import java.util.List;

import com.springboot.entity.BankEntity;
import com.springboot.entity.TransactionEntity;
import com.springboot.exception.DataNotFoundException;

public interface IBankService {
	public long Creation(BankEntity bankbean);
	public int showbalance(long accountnumber) throws DataNotFoundException ;
	public int deposit(long accountnumber, int depositamount) throws DataNotFoundException;
	public int withdraw(long accountnumber, int withdrawamount) throws DataNotFoundException;
	public int fundtransfer(long accountnumber1, long accountnumber2, int fundamount) throws DataNotFoundException;
	public List<TransactionEntity> printtransaction(long accountnumber) throws DataNotFoundException;

}
