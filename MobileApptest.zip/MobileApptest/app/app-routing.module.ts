import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { UpdatedetailsComponent } from './updatedetails/updatedetails.component';
import { MobiledetailsComponent } from './mobiledetails/mobiledetails.component';


const routes: Routes = [
 
  {
    path:'mobiledetails',
    component:MobiledetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
