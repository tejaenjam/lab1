import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MobiledetailsComponent } from './mobiledetails/mobiledetails.component';
//import { UpdatedetailsComponent } from './updatedetails/updatedetails.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MyserviceService } from './myservice.service';
import { OrderbyPipe } from './orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MobiledetailsComponent,
    
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   HttpClientModule,
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
