import { Component, OnInit } from '@angular/core';

import { MyserviceService, Mobile } from '../myservice.service';
@Component({
  selector: 'mobiledetails',
  templateUrl: './mobiledetails.component.html',
  styleUrls: ['./mobiledetails.component.css']
})
export class MobiledetailsComponent implements OnInit {

  service:MyserviceService;
  constructor(service:MyserviceService) { 
    this.service=service;
  }

  mobiles:Mobile[]=[];
  
  delete(mobId:string)
  {
    this.service.delete(mobId);
    this.mobiles=this.service.getMobiles();
  }
  
  column:string="mobId"; 
 
  order:boolean=true;

  sort(column:string)
  {    
    if(this.column==column)
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  ngOnInit() {
    this.service.fetchMobiles();
    this.mobiles=this.service.getMobiles();
  }

}
