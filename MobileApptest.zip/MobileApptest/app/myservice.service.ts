import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http:HttpClient;
  mobiles:Mobile[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchMobiles();
  }
  fetched:boolean=false;
  fetchMobiles()
  {
    this.http.get('./assets/Mobile.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getMobiles():Mobile[]
  {
    return this.mobiles;
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Mobile(o.mobId,o.mobName,o.mobPrice);
      this.mobiles.push(e);
    }
  }
  delete(mobId:string)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.mobiles.length;i++)
    {
      let e=this.mobiles[i];
      if(mobId==e.mobId)
      {
        foundIndex=i;
        break;
      }
    }
    this.mobiles.splice(foundIndex,1);
  }
}
export class Mobile{
 mobId:string;
  mobName:string;
  mobPrice:string;
    constructor(mobId:string,mobName:string,mobPrice:string)
    {
    this.mobId=mobId;
    this.mobName=mobName;
    this.mobPrice=mobPrice;
    }
}