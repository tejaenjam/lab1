package com.capg.dao;

import java.util.List;

import com.capg.bean.PayWalletBean;
import com.capg.bean.TransactionBean;

public interface PayWalletInterface {
   boolean createAccount(PayWalletBean bean);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validateAccount(long accountNo,String password);
   public List<TransactionBean> getTransactions(long accountNo) ;
}
