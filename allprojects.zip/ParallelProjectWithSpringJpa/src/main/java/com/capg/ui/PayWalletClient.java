package com.capg.ui;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.bean.TransactionBean;
import com.capg.service.PayWalletService;
public class PayWalletClient {


	public static void main(String[] args) {

		Scanner sc  = new Scanner(System.in);      
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		PayWalletService service =  context.getBean("PayWalletService",PayWalletService.class);
		String option;
		int c,balance;
		String choice,name,password,phoneNo;

		while(true)
		{
			System.out.println("******************************************\n");
			System.out.println("\t\tPAY XYZ WALLET\n");
			System.out.println("******************************************\n");

			System.out.println("1. Create account");
			System.out.println("2. Show balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw ");
			System.out.println("5. Fund transfer");
			System.out.println("6. Print Transaction");
			System.out.println("7. Exit");
			System.out.println("******************************************\n");
			System.out.println("\nEnter Your choice : ");
			option = sc.next();

			if(option.matches("[a-z]*")||option.matches("[A-Z]*")){	     
				System.out.println("Invalid Choice!!!");
				main(null);
			}
			switch (option) {
			case "1":
				System.out.println("Welcome to Pay Wallet");
				do{
					System.out.println("Enter Your Name : ");
					name = sc.next();
					c =service.nameValidate(name);
				}while(c!=1);
				
				do{
					System.out.println("Enter Your Phone Number : ");
					phoneNo = sc.next();
					c = service.mobNoValidate(phoneNo);
				}while(c!=1);

				Random r=new Random();
				long accountNo =r.nextInt(98765432);

				do{
					System.out.println("Enter Password : ");
					password = sc.next();
					c = service.passwordValidate(password);
				}while(c!=1);

				balance = 1000;
				boolean result =  service.createAccount(name,phoneNo,password,accountNo,balance);
				if(result){
					System.out.println("Account created successfully...!!!\n Your Account No is : "+accountNo);
				}break;

			case "2":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				boolean b1= service.validateAccount(accountNo,password);
				if(b1){
					balance = service.showBalance(accountNo);
					if(balance!=0){
						System.out.println("Your Current Balance : "+balance);
					}
					else{
						System.out.println("Oops..!!!, Please try again later");
					}
				}else{
					System.out.println("Please enter valid login details");
				}

				break;
				
			case "3":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				boolean b= service.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("Enter Amount for Deposit : ");
					int deposit = sc.nextInt();
					balance = service.depositAmount(accountNo,deposit);
					System.out.println("Amount Deposited Successfully...!!!\n");
					System.out.println("Updated Balance : "+balance);
				}
				else{
					System.out.println("Invalid login credantials...!!!!");
				}
				break;
				
			case "4":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b){
					balance = service.showBalance(accountNo);
					System.out.println("Your Current Balance : "+balance);
					System.out.println("Enter Amount for Withdrawn : ");
					int withdraw = sc.nextInt();
					balance = service.withdrawAmount(accountNo,withdraw);
					if(balance>=0){
						System.out.println("Amount Withdrawn Successfully...!!!\n");
						System.out.println("Updated Balance : "+balance);
					}
					else{
						System.out.println("Insufficient balance");
					}
				}


				else{
					System.out.println("Please enter valid login details");
				}
				break;

			case "5":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b){
					System.out.println("\nEnter Account No to Transfer");
					long  accno = sc.nextLong();
					System.out.println("Enter Amount : ");
					int amount = sc.nextInt();
					boolean transfer = service.fundTransfer(accountNo, accno, amount);
					if(transfer){
						System.out.println("Fund Transfered Successfully\n");
					}
					else{
						System.out.println("Oops..!!!, Please try again later");
					}
				}
				else{
					System.out.println("Please enter valid login details");
				}

				break;
			case "6":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= service.validateAccount(accountNo,password);
				if(b){
					List<TransactionBean> trans=service.getTransaction(accountNo);

					System.out.println("*********Transaction**********\n");

					for(TransactionBean tran:trans){
						System.out.println(tran);
					}

				}
				else {
					System.out.println("Oops..!!!, Please try again later");
				}
				break;

			case "7": 
				System.out.println("Thank You...!!! Visit again..!!!");
				System.exit(0);
			}

		}

	}

}
