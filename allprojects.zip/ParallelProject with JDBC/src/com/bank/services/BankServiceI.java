package com.bank.services;

import java.sql.SQLException;

import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public interface BankServiceI {
     boolean createAccount(String name,String phoneNo, String password, long accountNo,int balance) throws AccountNotCreatedException, ClassNotFoundException, SQLException;
     
     int showBalance(long accountNo) throws ZeroBalanceException, ClassNotFoundException, SQLException;
     int depositAmount(long accountNo, int deposit) throws ClassNotFoundException, SQLException, ZeroBalanceException;
     int withdrawAmount(long accountNo, int withdraw) throws InsufficientBalanceException, ClassNotFoundException, SQLException, ZeroBalanceException;
     boolean fundTransfer(long accountNo , long accno,int amount) throws ClassNotFoundException, SQLException, ZeroBalanceException;
     boolean validateAccount(long accountNo,String password) throws ClassNotFoundException, SQLException;
 	 String getTransaction(long accountNo) throws  AccountNotCreatedException, SQLException ;

}
