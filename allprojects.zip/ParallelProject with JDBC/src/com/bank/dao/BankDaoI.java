package com.bank.dao;

import java.sql.SQLException;

import com.bank.beans.BankBean;
import com.bank.exception.AccountNotCreatedException;
import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.ZeroBalanceException;

public interface BankDaoI {
   boolean createAccount(BankBean bankBean) throws AccountNotCreatedException;
   
   int showBalance(long accountNo) throws ZeroBalanceException;
   int depositBalance(long accountNo, int balance1);
     int withdrawBalance(long accountNo, int balance1) throws InsufficientBalanceException;
   boolean fundTransfer(long accountNo, long accno, int amount,int balance1);
   boolean validateAccount(long accountNo,String password);
	public String getTransaction(long accountNo) throws SQLException ;

}
