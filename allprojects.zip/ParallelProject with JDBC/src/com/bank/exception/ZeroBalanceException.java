package com.bank.exception;

public class ZeroBalanceException extends Exception{
	public String toString()
	{
		return "Your balance is Zero ";
	}
}
