package com.bank.exception;

public class AccountNotCreatedException extends Exception {
   public String toString()
   {
	   return "Problem in Account , Verify ";
   }
}
