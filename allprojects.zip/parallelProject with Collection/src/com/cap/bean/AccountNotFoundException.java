package com.cap.bean;

public class AccountNotFoundException extends RuntimeException{
	

	public AccountNotFoundException() {
		// TODO Auto-generated constructor stub
		super();
		System.out.println("invalid account");
	}
}