package com.cap.bean;

public class PasswordNotFoundException extends RuntimeException{
public PasswordNotFoundException()
{
	super();
System.out.println("Password is not validated");
}
}
//package com.cap.bean;

