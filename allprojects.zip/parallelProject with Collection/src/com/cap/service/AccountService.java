package com.cap.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cap.bean.Account;
import com.cap.dao.AccountDao;

public class AccountService implements AccountServiceI {
	AccountDao dao = new AccountDao();

	public boolean addData(String name, long phoneno, String dob, String password) {
		// TODO Auto-generated method stub
		long acc = phoneno + 1000;
		long balance = 1000;
		long amount = 0;
		Account abean = new Account(name, phoneno, dob, password, acc, balance, amount);

		if (dao.setData(abean)) {
			return true;

		} else {
			return false;
		}

	}

	public Account getInfo(long phoneno) {
		// TODO Auto-generated method stub
		Account ob = dao.getInfo(phoneno + 1000);

		return ob;
	}

	public boolean validation(long accno, String password) {
		// TODO Auto-generated method stub
		boolean ob1 = dao.validation(accno, password);
		return ob1;
	}

	public long deposit(long amount, long accno1, String password) {
		// TODO Auto-generated method stub
		long ob11 = dao.deposit(amount, accno1, password);
		return ob11;
	}

	public Account showbalance(long accno, String password) {
		// TODO Auto-generated method stub
		Account k = dao.showbalance(accno, password);
		// System.out.println("hi");
		return k;
	}

	public long withdraw(long amount, long accno2, String password) {
		// TODO Auto-generated method stub
		long k = dao.withdraw(amount, accno2, password);
		return k;
	}

	public long fund(long accno3, String password, long accno4, long amount) {
		// TODO Auto-generated method stub
		long bal1 = dao.fund(accno3, password, accno4, amount);
		return bal1;
	}

	public List transactionui() {
		AccountDao d = new AccountDao();
		// TODO Auto-generated method stub
		List trans1 = d.transaction();
		return trans1;
	}

	public boolean validatecheck1(long amount, long accno2) {
		// System.out.println("service");
		boolean t = dao.validatecheck1(amount, accno2);
		return t;

	}

	public boolean nameCheck(String name) {

		while (true) {
		
			if (Pattern.matches("[A-Z][a-z A-Z]*", name))
				return true;
			else
				return false;
		}

	}

	public boolean phonenumbercheck(String pno) {
		// TODO Auto-generated method stub
		if (pno.matches("[6-9][0-9]{9}")) {
						return true;
		}
			else
		  return false;
	}

	public boolean dateofbirthcheck(String dob) {
		// TODO Auto-generated method stub
		if (dob.matches("[0-9]{8}")) {
				return true;
		}
		else
		return false;
	}

	public boolean passcheck(String password) {
		// TODO Auto-generated method stub
		if(password.matches("[0-9]{8}"))
			return true;
		else
		return false;
	}


}
