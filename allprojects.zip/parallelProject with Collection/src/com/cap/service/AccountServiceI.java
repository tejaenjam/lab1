package com.cap.service;

import java.util.List;

import com.cap.bean.Account;

public interface AccountServiceI {
	public boolean addData(String name, long phoneno, String dob, String password);
	 Account getInfo(long phoneno);
	 boolean validation(long accno,String password);
	 long deposit(long amount,long accno1,String password);
	 Account showbalance(long accno,String password);
	long withdraw(long amount, long accno2,String password);
	 long fund(long accno3, String password, long accno4, long amount);
	 boolean validatecheck1(long amount,long accno2);
	 List transactionui();
}
