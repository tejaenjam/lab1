package com.cap.dao;

import com.cap.bean.AccountNotFoundException;

public interface AccountDaoI {
	 void Account(String name,String phoneno,String dob,String password);
	 boolean setData(com.cap.bean.Account abean);
	 com.cap.bean.Account getInfo(long acc) ;
	 boolean validation(long accno,String password);
	// com.cap.bean.Account deposit(long amt);
	 com.cap.bean.Account showbalance(long accno,String password) throws AccountNotFoundException, Exception;
	 long deposit(long amount, long accno1,String password);
	 long withdraw(long amount, long accno2,String password);
	 long fund(long accno3, String password, long accno4, long amount);  
}
