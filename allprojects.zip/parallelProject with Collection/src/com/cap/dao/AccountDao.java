package com.cap.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.AccountNotFoundException;
import com.cap.bean.PasswordNotFoundException;
import com.cap.bean.TransBean;

public class AccountDao implements AccountDaoI {
	int i = 351171;
	private HashMap<Long, Account> hm;
	private HashMap<TransBean, Long> hmt;
	private ArrayList listkey;
	long bacc;
	int dep2;
	int dep4;
	long t1, t2;

	
	public AccountDao() {
		hm = new HashMap<Long, Account>();
		hmt = new HashMap<TransBean, Long>();
		
	}

	public boolean setData(Account abean) {
	// TODO Auto-generated method stub
		if (hm.containsKey(abean.getAcc()))
		return false;
		else {
			hm.put(abean.getAcc(), abean);
			return true;
		}

	}

	public Account getInfo(long acc) {
		// TODO Auto-generated method stub
		if (hm.containsKey(acc)) {
			Account ob = (Account) hm.get(acc);
			return ob;
		}

		return null;
	}

	public boolean validation(long accno, String password) {
		// TODO Auto-generated method stub
		Account ob = (Account) hm.get(accno);
		if (hm.containsKey(accno) && ob.getPassword().equals(password)) {

			return true;
		}

		return false;
	}

	public Account showbalance(long accno,String password)  {
		// TODO Auto-generated method stub
			 
		Account bean = (Account) hm.get(accno);
		if(bean==null)
		{
			throw new AccountNotFoundException();
		}else if(bean.getPassword().equals(password))
		{
		// hm.put(bean.getAcc(), bean);
		bean.getBalance();
		}
		else
		{
			throw new AccountNotFoundException();
		}
		return bean;
	}
			
	

	public long deposit(long amount, long accno1,String password) {
		// TODO Auto-generated method stub
		Account bean = (Account) hm.get(accno1);
		if(bean==null) {
			throw new AccountNotFoundException();
		}
		else if(bean.getPassword().equals(password))
		{
		long d2 = bean.getBalance() + amount;
		bean.getAmount();
		bean.setBalance(d2);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		TransBean tb = new TransBean();
		tb.setBaccInitial(accno1);
		tb.setTransdate(formatter.format(date));
		tb.setTransBal(amount);
		tb.setTransMetd("deposit");
		tb.setTransId(++i);
		hmt.put(tb, accno1);
		return d2;
		}
		else
		{
			throw new AccountNotFoundException();
		}
			
	}
	
	public long withdraw(long amount, long accno2,String password) {
		// TODO Auto-generated method stub
		Account bean = (Account) hm.get(accno2);
		if(bean==null) {
			throw new AccountNotFoundException();
		}else if(bean.getPassword().equals(password)) {
		long d2 = bean.getBalance() - amount;
		bean.getAmount();
		bean.setBalance(d2);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		TransBean tb = new TransBean();
		tb.setBaccInitial(accno2);
		tb.setTransdate(formatter.format(date));
		tb.setTransBal(amount);
		tb.setTransMetd("withdrawl");
		tb.setTransId(++i);
		hmt.put(tb, accno2);
		return d2;
		}
		else
		{
			throw new AccountNotFoundException();
		}
	}

	public long fund(long accno3, String password, long accno4, long amount) {
		// TODO Auto-generated method stub
		if (hm.containsKey(accno3) && hm.containsKey(accno4)) {
			Account bean = (Account) hm.get(accno3);
			Account bean1 = (Account) hm.get(accno4);
			if (bean.getPassword().equals(password)) {
				t1 = bean.getBalance() - amount;
				t2 = bean1.getBalance() + amount;
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				Date date = new Date();
				TransBean tb = new TransBean();
				tb.setBaccInitial(accno3);
				tb.setBaccFinal(accno4);
				tb.setTransdate(formatter.format(date));
				tb.setTransBal(t1);
				tb.setTransMetd("funds");
				tb.setTransId(++i);
				hmt.put(tb, accno3);

			}

			return t1;

		}

		return 0;

	}

	public List transaction() {
		// TODO Auto-generated method stub
		listkey = new ArrayList(hmt.keySet());
		return listkey;
	}

	public boolean validatecheck1(long amount,long accno2) {
		Account bean = (Account) hm.get(accno2);
		
		if(bean.getBalance()>amount)
			return true;
		else
		{
		throw new PasswordNotFoundException();
		}
	}

	@Override
	public void Account(String name, String phoneno, String dob, String password) {
		// TODO Auto-generated method stub
		
	}

	
		
	

}

