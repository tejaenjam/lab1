package com.cap.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.Account;
import com.cap.bean.AccountNotFoundException;
import com.cap.service.AccountService;

public class AccountUI {
	AccountService service = new AccountService();
	Long phoneno;
	String pno;

	public void showoptions() {
		System.out.println(" Welcome to XYZ Bank");
		
		System.out.println("***********************************");
		
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit Balance");
		System.out.println("4.Withdraw Money");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transaction");
		System.out.println("7.Exit");
		
		System.out.println("***********************************");
		
		System.out.println("Enter Your choice : ");
	}

	public int getOption(Scanner sc) {
		try {
			int option = sc.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public void choose() {
		boolean run = true;
		while (run) {
			showoptions();
			Scanner sc = new Scanner(System.in);
			int option = getOption(sc);
			if (option == -1) {
				run = false;
			}
			switch (option) {
			case 1: { // Account Creation

				System.out.println("Enter your name");
				String name = sc.next();
				boolean name1 = service.nameCheck(name);
				// System.out.println(name1);
				while (true) {
					if (name1) {

						break;
					} else {
						System.out.println("Enter name in correct format");
						String name3 = sc.next();
						name1 = service.nameCheck(name3);
					}
				}
				System.out.println("Enter your mobile number");
				try {
					pno = sc.next();
				} catch (Exception ar) {
					System.out.println("enter correct number");
				}

				boolean pn = service.phonenumbercheck(pno);
				while (true) {
					if (pn)
						break;
					else {
						System.out.println("Enter valid mobile number");
						pno = sc.next();
						pn = service.phonenumbercheck(pno);
					}
				}
				System.out.println("Enter your date of birth");
				String dob = sc.next();
				boolean dob1 = service.dateofbirthcheck(dob);
				while (true) {
					if (dob1)
						break;
					else {
						System.out.println("Enter valid date of birth ");
						dob = sc.next();
						dob1 = service.dateofbirthcheck(dob);
					}
				}
				System.out.println("Enter your password");
				String password = sc.next();
				boolean pass = service.passcheck(password);
				while (true) {
					if (pass)
						break;
					else {
						System.out.println("Enter password in correct format");
						password = sc.next();
						pass = service.passcheck(password);
					}
				}
				phoneno = Long.parseLong(pno);
				if (service.addData(name, phoneno, dob, password)) {
					System.out.println("Account successfully created");
					//System.out.println("Account Created With No : "+phoneno);
					
					Account ob = service.getInfo(phoneno);
					System.out.println(ob.getAcc());
					System.out.println(ob.getDob());
					System.out.println(ob.getName());
					break;
				} else {
					System.out.println("Account already exists");

					break;
				}
			}
			case 2: // Show balance
			{
				System.out.println("Enter your account no");
				long accno = sc.nextLong();
				System.out.println("Enter your password");
				String password = sc.next();
				try {
					Account bal = service.showbalance(accno, password);
					System.out.println("The balance amount is " + bal.getBalance());

				} catch (AccountNotFoundException e) {
					System.out.println("an error occured " + e.getMessage());
				}
				break;
			}
			case 3: // deposit money
			{
				System.out.println("Enter your account no");
				long accno1 = sc.nextLong();
				System.out.println("Enter your password");
				String password = sc.next();
				try {
					// System.out.println("Account Validated successfully");
					System.out.println("Enter amount to deposit ");
					long amount = sc.nextLong();
					long ob11 = service.deposit(amount, accno1, password);

					System.out.println("The balance after deposit is " + ob11);
				} catch (AccountNotFoundException e) {
					System.out.println("an error occured " + e.getMessage());
				}
				break;
			}
			case 4: // Withdraw money
			{
				System.out.println("Enter your account no");
				long accno2 = sc.nextLong();
				System.out.println("Enter your password");
				String password = sc.next();
				try {
					System.out.println("Enter amount to withdrawn ");
					long amount = sc.nextLong();
					boolean t = service.validatecheck1(amount, accno2);
					if (t) {
						long ob11 = service.withdraw(amount, accno2, password);

						System.out.println("After withdrawn remianing balance is " + ob11);
					} else {
						System.out.println(".......Insufficient balance......");
						System.out.println("Enter amount again");
					}

				} catch (AccountNotFoundException e) {
					System.out.println("an error occured " + e.getMessage());
				}
				break;
			}
			case 5: // Transfer money
			{
				System.out.println("Enter your account no to transfer");
				long accno3 = sc.nextLong();
				System.out.println("Enter your password");
				String password = sc.next();
				while (true) {
					boolean ob4 = service.validation(accno3, password);
					if (ob4) {
						System.out.println("Enter your account no to receive");
						long accno4 = sc.nextLong();
						System.out.println("Enter fund amount to transfer");
						long amount = sc.nextLong();
						long bal1 = service.fund(accno3, password, accno4, amount);
						System.out.println("Remaining balance is " + bal1);
						break;
					} else {
						System.out.println("Enter correct details");
						System.out.println("Enter your account no ");
						accno3 = sc.nextLong();
						System.out.println("Enter your password");
						password = sc.next();
					}
				}
				break;
			}
			case 6: // Print Transactions
			{
				System.out.println("print  transaction");
				System.out.println("enter account number");
				long accno5 = sc.nextLong();
				System.out.println("enter password");
				String password1 = sc.next();
				while (true) {
					boolean ob4 = service.validation(accno5, password1);
					if (ob4) {
						System.out.println(" account no is correct");
						break;
					} else {
						System.out.println("Enter correct account no");
						accno5 = sc.nextLong();
					}
					long accno4 = sc.nextLong();
				

				}
			
			}
				List listui1 = service.transactionui();
				System.out.println(listui1);
				break;
			
			//}
		case 7: {
			
			System.out.println("You Logout From Your Account Succesfully");
			System.exit(0);
		}
			}	
		}
	}
		
	public static void main(String[] args) {
		AccountUI ui = new AccountUI();
		ui.choose();

	}
}
