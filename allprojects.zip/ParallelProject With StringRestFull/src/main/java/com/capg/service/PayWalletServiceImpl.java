package com.capg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.PayWalletDao;
import com.capg.dao.TransactionDao;
import com.capg.entities.PayWalletBean;
import com.capg.entities.TransactionBean;
import com.capg.exception.PayWalletException;


@Service
public class PayWalletServiceImpl implements PayWalletService {

	@Autowired
	PayWalletDao paywalletdao;

	@Autowired
	TransactionDao transactionDao;

	public PayWalletBean createAccount(PayWalletBean bank) throws PayWalletException {
		if(bank.getBal()==null || bank.getBal()<=0){
			throw new PayWalletException("Balance can not be 0");
		}else {
			paywalletdao.save(bank);
			return paywalletdao.findById(bank.getAccNo()).get();
		}
	}

	public PayWalletBean accountsDetails(Long accNo) throws PayWalletException {
		if(!paywalletdao.findById(accNo).isPresent()) {
				throw new PayWalletException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}else{
				return paywalletdao.findById(accNo).get();
		}
	}

	public Double showBalance(Long accNo) throws PayWalletException {
		if(!paywalletdao.findById(accNo).isPresent()) {
				throw new PayWalletException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}else{
			return  paywalletdao.findById(accNo).get().getBal();
		}
		
	}

	public Double deposit(Long accNo, Double amt) throws PayWalletException {

		Optional<PayWalletBean> bank = paywalletdao.findById(accNo);
		if (bank.isPresent()) {
			PayWalletBean tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			paywalletdao.save(tempEntity);
			TransactionBean trans = new TransactionBean(accNo, "Deposite", bank.get().getBal(),
					bank.get().getBal() + amt);
			transactionDao.save(trans);
			return showBalance(accNo);
		} else {
			throw new PayWalletException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public Double withdraw(Long accNo, Double amt) throws PayWalletException {
		Optional<PayWalletBean> bank = paywalletdao.findById(accNo);
		if (bank.isPresent()) {
			if(amt>showBalance(accNo)) {
				throw new PayWalletException("Insufficient Balance :-(");
			}else {
				PayWalletBean tempEntity = bank.get();
				tempEntity.setBal(bank.get().getBal() - amt);
				paywalletdao.save(tempEntity);
				TransactionBean trans = new TransactionBean(accNo, "Withdraw", bank.get().getBal(),bank.get().getBal() - amt);
				transactionDao.save(trans);
				return showBalance(accNo);	
			}
		} else {
			throw new PayWalletException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public Double fundTransfer(Long senderAcc, Double amt, Long reciverAcc) throws PayWalletException {
		Optional<PayWalletBean> senderAccount = paywalletdao.findById(senderAcc);
		Optional<PayWalletBean> reciverAccount = paywalletdao.findById(reciverAcc);
		if (senderAccount.isPresent() && reciverAccount.isPresent()) {
			
			PayWalletBean sender = senderAccount.get();
			sender.setBal(senderAccount.get().getBal() - amt);
			paywalletdao.save(sender);
			
			PayWalletBean reciver = reciverAccount.get();
			reciver.setBal(reciverAccount.get().getBal() + amt);
			paywalletdao.save(reciver);
			
			TransactionBean senderTrans = new TransactionBean(senderAcc, "Fund Transfer", senderAccount.get().getBal(),senderAccount.get().getBal() - amt);
			transactionDao.save(senderTrans);
			
			TransactionBean reciverTrans = new TransactionBean(reciverAcc, "Fund Recieved", reciverAccount.get().getBal(),amt + reciverAccount.get().getBal());
			transactionDao.save(reciverTrans);
			
			return showBalance(senderAcc);
		} else {
			throw new PayWalletException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}
	}

	public List<TransactionBean> printTransaction(Long accNo) {

		return transactionDao.printTransaction(accNo);
	}
}
