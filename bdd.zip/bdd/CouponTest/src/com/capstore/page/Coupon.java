package com.capstore.page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Coupon 
{
	public static WebElement element=null;
	public static WebElement setValidity(WebDriver driver) throws Throwable
	{
		Thread.sleep(1000);
		element=driver.findElement(By.id("validity"));
		return element;
	}
	public static WebElement setDiscount(WebDriver driver) throws Throwable
	{
		Thread.sleep(1000);
		element=driver.findElement(By.id("discount"));
		return element;
	}
	public static WebElement setEmail(WebDriver driver) throws Throwable
	{
		Thread.sleep(1000);
		element=driver.findElement(By.id("email"));
		return element;
	}
	public static WebElement setGenerateCoupon(WebDriver driver) throws Throwable
	{
		Thread.sleep(1000);
		element=driver.findElement(By.id("generateCoupon"));
		return element;
	}
}
