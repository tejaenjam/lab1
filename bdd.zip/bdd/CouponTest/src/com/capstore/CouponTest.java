package com.capstore;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capstore.page.Coupon;

public class CouponTest 
{
   public static void main(String[] args) throws Throwable
   {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\CVSR\\Desktop\\bdd\\webdriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();  	
       driver.navigate().to("http://localhost:4200");  
       driver.manage().window().maximize();  
       WebElement couponElement=Coupon.setValidity(driver);    
       couponElement.sendKeys("21-05-2019");
       WebElement couponElement1=Coupon.setDiscount(driver);    
       couponElement1.sendKeys("30");
       WebElement couponElement2=Coupon.setEmail(driver);    
       couponElement2.sendKeys("joycedeborah97@gmail.com");
       WebElement couponElement3=Coupon.setGenerateCoupon(driver);    
       couponElement3.click();
       Thread.sleep(2000);
       driver.close();
   }
}
