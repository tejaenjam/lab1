import { Component, OnInit } from '@angular/core';
import { Transactions } from 'src/Models/Transactions';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cash-transfer',
  templateUrl: './cash-transfer.component.html',
  styleUrls: ['./cash-transfer.component.css']
})
export class CashTransferComponent implements OnInit {

  isLogin:boolean=true;
  createdTransaction:Transactions;
  router:Router;
  service:ServiceService;
  
  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
    this.router=router;
  }
  fundTransfer(data:any){
    let caccount_first=data.caccount;
    let caccount_second=data.caccount_second;
    let cbalance=data.cbalance;
    var ttype:string;
    ttype="Fund Transfer"
    this.service.depositeBalance(caccount_first,cbalance);
    this.service.withdrawBalance(caccount_second,cbalance)
    this.createdTransaction=new Transactions("123",caccount_first,caccount_second,data.cbalance,ttype);
    this.service.addTransaction(this.createdTransaction)
    this.router.navigate(['view']);
  }
  ngOnInit() {
  }

}
