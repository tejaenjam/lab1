package com.cap.dao;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cap.entities.BankEntity;
import com.cap.entities.TransEntity;


public class BankDao implements BankDaoI {

	
	long bacc;
	int balance11,data1,data2,data3,data4;
	EntityManager entitymanager;

	public BankDao()  {
		entitymanager=JPAUtil.getEntityManager();
	}
	
	public void gettransactionbegin(){
		entitymanager.getTransaction().begin();
	}
	
	public void gettransactioncommit(){
		entitymanager.getTransaction().commit();
	}

	
	
	public long createAccount1(BankEntity bean) {
		bacc = bean.getBacc();
		entitymanager.persist(bean);
		return bacc;
	}

	public int showbalace1(long account1, String password1) {
	
//		TypedQuery<BankEntity> tq=entitymanager.createQuery("select ar from BankEntity ar",BankEntity.class);
//		List<BankEntity> st=tq.getResultList();
//		for(BankEntity q1:st)
//		{
//			if(account1==q1.getBacc()&& (password1.equals(q1.getBpass())))
//			{
//				balance11= q1.getBbal();
//			}else {
//				throw new AccountNotFoundException("enter valid account number or password");
//			}
//		}
		
		BankEntity be = entitymanager.find(BankEntity.class,new Long(account1));
		if(be==null)
		{
			throw new AccountNotFoundException("enter valid account number ");	
		}
		else if(password1.equals(be.getBpass())){	
		balance11=be.getBbal();
		return balance11;
		}
		else 
		{
			throw new PasswordNotFoundException("password is not correct");
		}
		
	}

	public int deposit1(long account2, String password2, int dep1) {
		
		TypedQuery<BankEntity> tq=entitymanager.createQuery("select ar from BankEntity ar",BankEntity.class);
		List<BankEntity> st=tq.getResultList();
		for(BankEntity q1:st)
		{
			if(account2==q1.getBacc()&& (password2.equals(q1.getBpass())))
			{
			data1=dep1+q1.getBbal();
			}else {
				throw new AccountNotFoundException("enter valid account number or password");
			}
		}
		
		Query q=entitymanager.createQuery("update BankEntity set Account No = account2 where Balance = data1 ");
		q.executeUpdate();
		
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		TransEntity tb = new TransEntity();
		tb.setBaccInitial(account2);
		tb.setTransdate(formatter.format(date));
		tb.setTransBal(dep1);
		tb.setTransMetd("deposit");
//		tb.setTransId(++i);
		
		//hmt.put(tb, account2);
		
		
		return data1;
	}

	public int withdrawl1(long account3, String password3, int dep3) {
		
		TypedQuery<BankEntity> tq=entitymanager.createQuery("select ar from BankEntity ar",BankEntity.class);
		List<BankEntity> st=tq.getResultList();
		for(BankEntity q1:st)
		{
			if(account3==q1.getBacc()&& (password3.equals(q1.getBpass())))
			{
			data2=q1.getBbal()-dep3;
			}else {
				throw new AccountNotFoundException("enter valid account number or password");
			}
		}
		
		Query q=entitymanager.createQuery("update BankEntity set Account No = account3 where Balance = data2 ");
		q.executeUpdate();
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		TransEntity tb = new TransEntity();
		tb.setBaccInitial(account3);
		tb.setTransdate(formatter.format(date));
		tb.setTransBal(dep3);
		tb.setTransMetd("withdrawl");
//		tb.setTransId(++i);
		//hmt.put(tb, account3);
		return data2;
	}

	public int fund1(long account31, long account32, String password31, int k1) {
		
		TypedQuery<BankEntity> tq=entitymanager.createQuery("select ar from BankEntity ar",BankEntity.class);
		List<BankEntity> st=tq.getResultList();
		for(BankEntity q1:st)
		{
			if(account31==q1.getBacc() && (password31.equals(q1.getBpass())) && account31==q1.getBacc())
			{
			data3=q1.getBbal()-k1;
			data4=q1.getBbal()+k1;
			}else {
				throw new AccountNotFoundException("enter valid account numbers or password");
			}
		}
		
		Query q=entitymanager.createQuery("update BankEntity set Account No = account31 where Balance = data3 ");
		q.executeUpdate();	
		Query q3=entitymanager.createQuery("update BankEntity set Account No = account32 where Balance = data4 ");
		q3.executeUpdate();	
       return data3;
	}
	
	public List transaction() {
		TypedQuery<BankEntity> tq=entitymanager.createQuery("select ar from BankEntity ar",BankEntity.class);
		List<BankEntity> st=tq.getResultList();
		return st;
	}

//	public void checkfund(int a1, int k1) {
//		if (a1 < k1) {
//			throw new Balance();
//		}
//
//	}

	public boolean validation21(long account1) {
		// TODO Auto-generated method stub

		if (true) {
//			hm.containsKey(account1)
			return true;
		} else {
			return false;
		}
	}

	public boolean validation(long account1, String password1) {
		// TODO Auto-generated method stub
		if (true) {
//			BankEntity bean4 = hm.get(account1);
//			hm.containsKey(account1)
			if (true) {
//				bean4.getBpass().equals(password1)
				return true;
			}
		}
		return false;
	}

	
	
	
	
//	public boolean checkbal(int dep3) {
//		if (inibal >= dep3) {
//			return false;
//		} else {
//			return true;
//		}
//	}
}
