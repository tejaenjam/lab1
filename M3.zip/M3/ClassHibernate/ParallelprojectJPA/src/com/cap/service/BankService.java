package com.cap.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cap.dao.BankDao;
import com.cap.dao.BankDaoI;
import com.cap.entities.BankEntity;

public class BankService implements BankServiceI

{
	BankDao d = new BankDao();

	public long createAccount(BankEntity bean) {
		d.gettransactionbegin();
		long accNo = d.createAccount1(bean);
		d.gettransactioncommit();
		return accNo;
	}

	public int showbalance(long account1, String password1) {
		d.gettransactionbegin();
		int bal = d.showbalace1(account1, password1);
		d.gettransactioncommit();
		return bal;
	}

	public int deposit(long account2, String password2, int dep1) {
		d.gettransactionbegin();
		int d1 = d.deposit1(account2, password2, dep1);
		d.gettransactioncommit();
		return d1;
	}

	public int withdrawl(long account3, String password3, int dep3) {
		d.gettransactionbegin();
		int d3 = d.withdrawl1(account3, password3, dep3);
		d.gettransactioncommit();
		return d3;
	}

	public int fund(long account31, long account32, String password31, int k1) {
		d.gettransactionbegin();
		int d11 = d.fund1(account31, account32, password31, k1);
		d.gettransactioncommit();
		return d11;
	}
	
	public List transactionui() {
		d.gettransactionbegin();
		List trans1 = d.transaction();
		d.gettransactioncommit();
		return trans1;
	}

	public boolean validation2(long account1) { // account
		// TODO Auto-generated method stub
		boolean d11 = d.validation21(account1);
		return d11;
	}

	public boolean validation(long account1, String password1) { // password
		// TODO Auto-generated method stub
		boolean d11 = d.validation(account1, password1);
		return d11;
	}

	

	public boolean validbal(int dep3) {
		// TODO Auto-generated method stub
//		boolean aq = d.checkbal(dep3);
		boolean aq=true;
		return aq;
	}

	// check mobile number
	public boolean numbercheck(String bnum2) {
		// TODO Auto-generated method stub

		if ((bnum2.length()) == 10 && bnum2.matches("[6-9][0-9]{9}")) {

			return true;
		} else {
			return false;

		}

	}

	public boolean checkpassword(String bpass1) {
		// TODO Auto-generated method stub

		if (bpass1.length() < 8) {
			return false;

		} else {
			return true;
		}

	}

	// check date of birth
	public boolean dobcheck(String bdob1) {
		// TODO Auto-generated method stub

		if (bdob1.length() == 8 && bdob1.matches("[0-9]*")) {
			return true;
		} else {
			return false;

		}

	}

	public boolean namecheck(String bname1) {

		if (Pattern.matches("[A-Z][A-Za-z( )(.)]*", bname1)) {
			
			return true;
		} else {
			
			return false;
		}
	}

}
