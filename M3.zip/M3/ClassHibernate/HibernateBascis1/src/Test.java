import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure();
		SessionFactory fact =cfg.buildSessionFactory();
		Session sess =fact.openSession();
		Transaction tran=sess.beginTransaction();
		//EmployeePojo e=(EmployeePojo) sess.get(EmployeePojo.class, 123);
		//System.out.println(e.getEname());
		EmployeePojo empp=new EmployeePojo(123456,"aravind",1234);
		sess.save(empp);
		EmployeePojo e=(EmployeePojo) sess.get(EmployeePojo.class, 123456);
	    e.setEname("dharma");
	    sess.update(e);
		tran.commit();	
	}
}
