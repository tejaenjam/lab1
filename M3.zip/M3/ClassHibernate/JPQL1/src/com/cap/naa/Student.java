package com.cap.naa;

public class Student {

}
