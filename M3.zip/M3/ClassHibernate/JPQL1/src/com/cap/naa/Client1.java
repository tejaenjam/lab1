package com.cap.naa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Client1 {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("ara1");
		EntityManager em=emf.createEntityManager();
		em.getTransaction().begin();
		
		Address ar1=new Address(0,85, "teachers", "hanamkonda");
		Address ar2=new Address(0,74, "exerci", "hyd");
		Address ar3=new Address(0,55, "colo", "qwcity");
		
		em.persist(ar1);
		em.persist(ar2);
		em.persist(ar3);
		
		
		
		//fetch display
		
		TypedQuery<Address> tq=em.createQuery("select ar from Address ar",Address.class);
		List<Address> st=tq.getResultList();
		for(Address a1:st)
		{
			System.out.println(a1.getSid());
			System.out.println(a1.getHno());
			System.out.println(a1.getColony());
			System.out.println(a1.getCity());
			
		}
		
		//update
		
//		Query q=em.createQuery("update Address set hno = 60 where hno < 75 ");
//		q.executeUpdate();
		
		//delete

//		Query q=em.createQuery("delete from Address where hno=60");
//		q.executeUpdate();
			
		em.getTransaction().commit();
		
		
	}

}
