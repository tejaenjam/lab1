import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CrudoperationsComponent } from './crudoperations/crudoperations.component';
//import { Crudoperations1Component } from './crudoperations1/crudoperations1.component';
//import { Crudoperations2Component } from './crudoperations2/crudoperations2.component';

import { FormsModule} from '@angular/forms'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { SlayerService } from './slayer.service';
import { Pipe1Pipe } from './pipe1.pipe';
import { SearchopComponent } from './searchop/searchop.component';


@NgModule({
  declarations: [
    AppComponent,
    CrudoperationsComponent, Pipe1Pipe, SearchopComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule
  ],
  providers: [HttpClient,SlayerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
