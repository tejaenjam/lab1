import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SlayerService {

empbean:employeebean[]=[];
hc:HttpClient;

constructor(hc:HttpClient) {this.hc=hc; }

  
ab:boolean=false;
fetchinfo(){
  this.hc.get("./assets/employeedetails.json").subscribe
  (data1=>{
    if(!this.ab)
    {
      this.convert(data1);
      this.ab=true;
    }
  });
}
convert(d :any)
{
  for(let o of d)
  {
    let e=new employeebean(o.id,o.name,o.price,o.category)
    this.empbean.push(e);
  }
}


getinfo():employeebean[]{
  return this.empbean;
}


delete(id1:string)
{
  let  x:number=-1;
 for(let i=0;i< this.empbean.length;i++)
 {
   let e=this.empbean[i];
   if(id1==e.id)
   {
     x=i;
     break;
   }
 }
 this.empbean.splice(x,1);
 console.log(this.empbean)
}

add(o:any)
{
  this.empbean.push(o);
}



  search(id:string):employeebean
  {
   
    let o:employeebean
    for(let i=0;i<this.empbean.length;i++)
    {
     
       o =  this.empbean[i];
      if(id==o.id)
      {
        return o; 
      }
    } 
  }
}


export class employeebean{
  name:string;
  price:number;
  id:string;
  category:string;
  
  constructor(id:string,name:string,price:number,category:string)
  {
    this.name=name;
    this.id=id;
    this.category=category;
    this.price=price;
  }
}
