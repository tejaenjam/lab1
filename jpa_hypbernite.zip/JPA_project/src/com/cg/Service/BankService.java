package com.cg.Service;


import java.sql.SQLException;

import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOI;
import com.cg.entity.Account;

class MyException extends Exception {
	String str;

	MyException(String s) {
		str = s;

	}

	public String toString() {
		return (str);
	}

}

public class BankService implements BankServiceI {
	BankDAO bd = new BankDAO();

	@Override
	public boolean checkName(String name) {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new MyException("Enter Valid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}

		}
		return false;

	}

	@Override
	public long getBalance(long accNo) {
		long acc = bd.getBalance(accNo);
		return acc;

	}

	@Override
	public String getTransaction(long accNo) {
		String str = bd.getTransaction(accNo);
		return str;

	}

	@Override
	public void setBalance(long accNo, long bal, String st)  {
		bd.setBalance(accNo, bal, st);

	}

	@Override
	public String addAccount(String name, long mobile,  String password)
			 {
			Account bb = new Account(name, mobile, password, 500, "Account Created Successfully\n Account Intial Balance is Rs.500");
			long accNo=bd.setData(bb);
			return "  Your Account Created Successfully \n Your Account number is " + accNo;
			 }

	@Override
	public boolean checkAccNo(long acc) {
		try {
			if (bd.checkAccNo(acc)) {

				return true;
			}

			else
				throw new MyException("Enter Correct Account Number");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkPass(String st,long accNo) {
		try {
			if (bd.checkPassword(st,accNo)) {

				return true;
			} else
				throw new MyException("Enter Correct Password");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkM(long mob) {
		// TODO Auto-generated method stub
		String s = Long.toString(mob);
		int n = s.length();
		try {
			if (n == 10) {
				return true;
			} else {
				throw new MyException("Enter Valid Phone Number");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	@Override
	public boolean checkP(String password) {
		// TODO Auto-generated method stub
		try {
			if (password.length() >= 5) {
				return true;
			} else {
				throw new MyException("Your Password should be more than 5 characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}
	
}
