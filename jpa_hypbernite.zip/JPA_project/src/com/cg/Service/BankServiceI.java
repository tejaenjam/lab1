package com.cg.Service;



import com.cg.entity.Account;



public interface BankServiceI {

	long getBalance(long accNo);

	String getTransaction(long accNo);

	void setBalance(long accNo, long bal, String st) ;

	
	boolean checkAccNo(long acc) ;

	boolean checkPass(String st,long accNo);

	boolean checkName(String name);

	boolean checkM(long mob);

	boolean checkP(String password);

	String addAccount(String name, long mobile, String password) ;

	
}
