package com.cg.dao;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DataBase {
	public EntityManager getConnection() {
EntityManagerFactory emf=Persistence.createEntityManagerFactory("ding");
	
	EntityManager em=emf.createEntityManager();
	return em;
	}

}