package com.capg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.PayWalletBean;
import com.capg.bean.TransactionBean;
import com.capg.dao.PayWalletDao;

class MyException extends Exception
{
	private static final long serialVersionUID = 1L;
	String s1;
	MyException(String s)
	{
		 s1=s;
	}
	public String toString()
	{
		return (s1);
	}
}
@Service("PayWalletService")
public class PayWalletService implements PayWalletServiceInterface
{
	int balance;
	@Autowired
	private PayWalletDao dao;

	@Override
	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance) {
		
		PayWalletBean bean = new PayWalletBean();
	    bean.setName(name);
	    bean.setPhoneNo(phoneNo);
	    bean.setPassword(password);
	    bean.setAccountNo(accountNo);
	    bean.setBalance(balance);
	    
	    boolean result = dao.createAccount(bean);
		
	    return result;
	}

	@Override
	public int showBalance(long accountNo) {
	
		balance = dao.showBalance(accountNo);
	
		 return balance;
	}

	@Override
	public int depositAmount(long accountNo, int deposit) {
		int balance;
	
		 balance = dao.depositBalance(accountNo, deposit);
		 return balance;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance;
		
		 balance = dao.withdrawAmount(accountNo,withdraw);
		 return balance;
	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
	
		boolean fund = dao.fundTransfer(accountNo,accno,amount);
	      return fund;
	}

	@Override
	public boolean validateAccount(long accountNo, String password) {
	
		boolean b = dao.validateAccount(accountNo,password);
	    return b;
	}

	@Override
	public List<TransactionBean> getTransaction(long accountNo) {

	   List<TransactionBean> l = dao.getTransactions(accountNo);
	
	   return l;
	}

	public int passwordValidate(String password) {
		try
		{
		if(password.length()>3)
			return 1;
		else
			throw new MyException("password length should be greater than 4");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			return 0;
	}

	@Override
	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}

	@Override
	public int mobNoValidate(String phoneNo) {
		try
		{
			if(phoneNo.matches("[6-9][0-9]{9}"))
					return 1;
			else
				throw new MyException("Enter valid mobile number");
				
		}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}

	@Override
	public int nameValidate(String name) {
		try
		{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		
		else
		throw new MyException("Enter again, First letter should be capital");
	}
		catch(MyException e)
		{
			System.out.println(e);
		}
		return 0;
	}
	
}