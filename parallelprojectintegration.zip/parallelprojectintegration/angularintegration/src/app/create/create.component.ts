import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { empty } from 'rxjs';
import { ConcatSource } from 'webpack-sources';
import { ServicelayerService } from '../servicelayer.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  router:Router;
  servicelayer:ServicelayerService;
  constructor(router:Router,servicelayer:ServicelayerService) {
     this.router=router;
    this.servicelayer=servicelayer;
  }

    
  create(data:any){
    if((data.newcustomername=="") || (data.newphonenumber=="" ) || (data.newdateofbirth=="") || (data.newpassword=="") || (data.newlocation=="") ||(data.newaccounttype=="") ||(data.newbalance== "")){
      alert("no blank spaces")
    }
    else{
  let returnRxjs = this.servicelayer.createaccount(data.newcustomername,data.newphonenumber,data.newdateofbirth,data.newpassword,data.newlocation,data.newaccounttype,data.newbalance)
  returnRxjs.subscribe((data) =>{
            alert("Account id is "+data);
            this.router.navigate(['useraction']);
          },(error) =>{
            console.log(error)
            alert("Failed")
          })
    } 
}
  ngOnInit() {
  }

}
